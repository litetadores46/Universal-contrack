type ContractJSON = {
  _format: string;
  contractName: string;
  sourcename: string;
  abi: unknown[];
  bytecode: string;
  deployedBytecode: string;
  linkReferences: Record<string, unknown>;
};

export namespace contracts {
  // Token
  export const Token: ContractJSON;
  export const TokenStorage: ContractJSON;
  // Roles
  export const AgentRole: ContractJSON;
  export const AgentRoleUpgradeable: ContractJSON;
  export const Roles: ContractJSON;
  // registry
  export const ClaimTopicsRegistry: ContractJSON;
  export const IdentityRegistry: ContractJSON;
  export const IdentityRegistryStorage: ContractJSON;
  export const TrustedIssuersRegistry: ContractJSON;
  // registry/Storage
  export const CTRStorage: ContractJSON;
  export const IRSStorage: ContractJSON;
  export const IRStorage: ContractJSON;
  export const TIRStorage: ContractJSON;
  // proxy
  export const AbstractProxy: ContractJSON;
  export const ClaimTopicsRegistryProxy: ContractJSON;
  export const IdentityRegistryProxy: ContractJSON;
  export const IdentityRegistryStorageProxy: ContractJSON;
  export const ModularComplianceProxy: ContractJSON;
  export const TokenProxy: ContractJSON;
  export const TrustedIssuersRegistryProxy: ContractJSON;
  // proxy/authority
  export const IAFactory: ContractJSON;
  export const TREXImplementationAuthority: ContractJSON;
  // factory
  export const TREXFactory: ContractJSON;
  // gateway
  export const TREXGateway: ContractJSON;
  // compliance
  export const MCStorage: ContractJSON;
  export const ModularCompliance: ContractJSON;
  // compliance/modular/modules
  export const AbstractModule: ContractJSON;
  export const AbstractModuleUpgradeable: ContractJSON;
  export const ModuleProxy: ContractJSON;
}

export namespace interfaces {
  export const IToken: ContractJSON;
  export const IClaimTopicsRegistry: ContractJSON;
  export const IIdentityRegistry: ContractJSON;
  export const IIdentityRegistryStorage: ContractJSON;
  export const ITrustedIssuersRegistry: ContractJSON;
  export const IProxy: ContractJSON;
  export const IIAFactory: ContractJSON;
  export const ITREXImplementationAuthority: ContractJSON;
  export const ITREXFactory: ContractJSON;
  export const ITREXGateway: ContractJSON;
  export const IModularCompliance: ContractJSON;
  export const IModule: ContractJSON;
}
